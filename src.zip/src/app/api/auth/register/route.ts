import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { registerUser } from "@/lib/auth";
import { sendEmail, welcomeEmail } from "@/lib/email";
import { checkRateLimit, clientIp } from "@/lib/rate-limit";



const registerSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Enter a valid email"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  phone: z.string().optional(),
});

export async function POST(request: NextRequest) {
  // Spam guard: 5 signups per minute per IP.
  const gate = checkRateLimit(`register:${clientIp(request)}`, 5, 60_000);
  if (!gate.allowed) {
    return NextResponse.json({ success: false, message: "Too many signups. Wait a minute and try again." }, { status: 429 });
  }
  try {
    const body = await request.json();
    const data = registerSchema.parse(body);
    const user = await registerUser(data);
     // Welcome mail (never blocks signup — sendEmail never throws).
    const mail = welcomeEmail(user.name || "there");
    await sendEmail(user.email, mail.subject, mail.html, mail.text);
    return NextResponse.json({ success: true, user }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, message: error.issues[0]?.message || "Invalid input" },
        { status: 400 }
      );
    }
    const message = error instanceof Error ? error.message : "Something went wrong";
    return NextResponse.json({ success: false, message }, { status: 400 });
  }
}
