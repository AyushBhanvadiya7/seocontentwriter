import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, generations } from "@/db/schema";
import { requireAdmin } from "@/lib/session";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    await requireAdmin();
    const list = await db.query.users.findMany({
      orderBy: desc(users.createdAt),
      columns: { passwordHash: false },
      limit: 200,
    });
    const gens = await db.query.generations.findMany({ orderBy: desc(generations.createdAt), limit: 200 });
    return NextResponse.json({ success: true, users: list, generations: gens });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Forbidden";
    return NextResponse.json({ success: false, message }, { status: 403 });
  }
}
