import type { MetadataRoute } from "next";

// Served at /robots.txt — tells Google what it may and may not crawl.
const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: [
          "/api/",
          "/admin/",
          "/dashboard",
          "/billing",
          "/contents/",
          "/library",
          "/projects/",
          "/settings",
          "/forgot-password",
          "/reset-password",
        ],
      },
    ],
    sitemap: `${APP_URL}/sitemap.xml`,
  };
}
