"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Loader2, Users, FileText, AlertCircle } from "lucide-react";

export default function AdminPage() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/admin/users")
      .then((r) => r.json())
      .then((d) => {
        if (d.success) setData(d);
        else setError(d.message);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-12 text-center">
        <AlertCircle className="mx-auto h-8 w-8 text-red-500" />
        <p className="mt-2 text-slate-700">{error}</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="text-2xl font-semibold text-slate-900">Admin</h1>
      <p className="text-sm text-slate-600">Users, generations, spend and system settings.</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <Users className="h-5 w-5 text-blue-600" />
          <p className="mt-2 text-2xl font-semibold text-slate-900">{data.users.length}</p>
          <p className="text-sm text-slate-500">Users</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <FileText className="h-5 w-5 text-blue-600" />
          <p className="mt-2 text-2xl font-semibold text-slate-900">{data.generations.length}</p>
          <p className="text-sm text-slate-500">Generations</p>
        </div>
      </div>

      <div className="mt-6 flex gap-3">
        <Link
          href="/admin/prompts"
          className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
        >
          Prompt editor
        </Link>
      </div>

      <div className="mt-8">
        <h2 className="text-lg font-semibold text-slate-900">Recent generations</h2>
        <div className="mt-3 overflow-hidden rounded-xl border border-slate-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="px-4 py-3">ID</th>
                <th className="px-4 py-3">User</th>
                <th className="px-4 py-3">Model</th>
                <th className="px-4 py-3">Tokens</th>
                <th className="px-4 py-3">Credits</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Date</th>
              </tr>
            </thead>
            <tbody>
              {data.generations.map((g: any) => (
                <tr key={g.id} className="border-t border-slate-100">
                  <td className="px-4 py-3">{g.id}</td>
                  <td className="px-4 py-3">{g.userId}</td>
                  <td className="px-4 py-3">{g.modelName}</td>
                  <td className="px-4 py-3">{g.tokensIn + g.tokensOut}</td>
                  <td className="px-4 py-3">{g.creditsUsed}</td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${g.status === "completed" ? "bg-green-100 text-green-700" : g.status === "refunded" ? "bg-red-100 text-red-700" : "bg-slate-100 text-slate-700"}`}>
                      {g.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">{new Date(g.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
