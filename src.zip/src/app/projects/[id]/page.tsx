"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams } from "next/navigation";
import {
  Loader2,
  Upload,
  Search,
  FileText,
  Plus,
  Filter,
  Sparkles,
  Trash2,
  Edit3,
  CheckCircle,
  X,
  Download,
} from "lucide-react";

interface Keyword {
  id: number;
  keyword: string;
  volume?: number;
  difficulty?: number;
  intent?: string;
  status: string;
  cluster?: { name: string } | null;
}

interface Project {
  id: number;
  name: string;
  websiteUrl: string;
  businessDescription: string;
  language: string;
  targetCountry: string;
  targetCity?: string;
}

export default function ProjectWorkspacePage() {
  const params = useParams();
  const projectId = parseInt(params.id as string, 10);
  const [tab, setTab] = useState("keywords");
  const [project, setProject] = useState<Project | null>(null);
  const [keywords, setKeywords] = useState<Keyword[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [uploading, setUploading] = useState(false);
  const [uploadReport, setUploadReport] = useState<any>(null);
  const [previewRows, setPreviewRows] = useState<any[]>([]);
  const [sourceId, setSourceId] = useState<number | null>(null);
  const [selectedRows, setSelectedRows] = useState<Set<number>>(new Set());
  const [pastedKeywords, setPastedKeywords] = useState("");
  const [showPaste, setShowPaste] = useState(false);
  const [generateKeyword, setGenerateKeyword] = useState<Keyword | null>(null);

  useEffect(() => {
    loadProject();
    loadKeywords();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  async function loadProject() {
    const res = await fetch(`/api/projects/${projectId}`);
    const data = await res.json();
    if (data.success) setProject(data.project);
  }

  async function loadKeywords() {
    setLoading(true);
    const res = await fetch(`/api/projects/${projectId}/keywords?limit=200`);
    const data = await res.json();
    if (data.success) setKeywords(data.keywords);
    setLoading(false);
  }

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setUploadReport(null);
    setPreviewRows([]);
    const formData = new FormData();
    formData.append("file", file);
    const res = await fetch(`/api/projects/${projectId}/sources`, { method: "POST", body: formData });
    const data = await res.json();
    setUploading(false);
    if (data.success) {
      setSourceId(data.source.id);
      setPreviewRows(data.preview);
      setUploadReport(data.report);
    } else {
      alert(data.message);
    }
  }

  async function commitKeywords() {
    if (!sourceId) return;
    const excluded = Array.from(selectedRows);
    const res = await fetch(`/api/projects/${projectId}/sources/${sourceId}/commit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rows: previewRows, excluded }),
    });
    const data = await res.json();
    if (data.success) {
      setPreviewRows([]);
      setUploadReport(null);
      setSourceId(null);
      loadKeywords();
    } else {
      alert(data.message);
    }
  }

  async function addPastedKeywords() {
    const list = pastedKeywords
      .split(/[\n,]+/)
      .map((k) => k.trim())
      .filter(Boolean);
    if (list.length === 0) return;
    const res = await fetch(`/api/projects/${projectId}/keywords`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ keywords: list }),
    });
    const data = await res.json();
    if (data.success) {
      setPastedKeywords("");
      setShowPaste(false);
      loadKeywords();
    } else {
      alert(data.message);
    }
  }

  async function updateKeywordStatus(id: number, status: string) {
    const res = await fetch(`/api/keywords/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    if (res.ok) loadKeywords();
  }

  async function deleteKeyword(id: number) {
    if (!confirm("Delete this keyword?")) return;
    await fetch(`/api/keywords/${id}`, { method: "DELETE" });
    loadKeywords();
  }

  const filtered = useMemo(() => {
    return keywords.filter((k) => {
      const matchesQ = k.keyword.toLowerCase().includes(q.toLowerCase());
      const matchesStatus = statusFilter ? k.status === statusFilter : true;
      return matchesQ && matchesStatus;
    });
  }, [keywords, q, statusFilter]);

  if (!project) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">{project.name}</h1>
          <p className="text-sm text-slate-600">
            {project.websiteUrl} · {project.targetCity || project.targetCountry} · {project.language.toUpperCase()}
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => {
              setTab("keywords");
              if (keywords.length > 0) setGenerateKeyword(keywords[0]);
            }}
            className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
          >
            <Sparkles className="h-4 w-4" /> Make content
          </button>
        </div>
      </div>

      <div className="mt-6 border-b border-slate-200">
        <nav className="flex gap-6 overflow-x-auto">
          {["keywords", "clusters", "links", "content", "brand voice", "insights"].map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`whitespace-nowrap border-b-2 pb-2 text-sm font-medium capitalize ${
                tab === t ? "border-blue-600 text-blue-700" : "border-transparent text-slate-600 hover:text-slate-900"
              }`}
            >
              {t}
            </button>
          ))}
        </nav>
      </div>

      {tab === "keywords" && (
        <div className="mt-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-200 hover:bg-slate-50">
                <Upload className="h-4 w-4" />
                Upload keyword file
                <input type="file" className="hidden" onChange={handleUpload} accept=".csv,.xlsx,.xls,.txt,.json,.pdf,.docx,.xml" />
              </label>
              <button
                onClick={() => setShowPaste(!showPaste)}
                className="inline-flex items-center gap-2 rounded-lg bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-200 hover:bg-slate-50"
              >
                <Plus className="h-4 w-4" /> Paste keywords
              </button>
              {uploading && <Loader2 className="h-4 w-4 animate-spin text-blue-600" />}
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search keywords..."
                  className="w-full rounded-lg border border-slate-300 py-2 pl-9 pr-3 text-sm sm:w-64"
                />
              </div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="">All statuses</option>
                <option value="new">New</option>
                <option value="in_progress">In progress</option>
                <option value="done">Done</option>
                <option value="skipped">Skipped</option>
              </select>
            </div>
          </div>

          {showPaste && (
            <div className="mt-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
              <label className="block text-sm font-medium text-slate-700">Paste keywords (one per line or comma-separated)</label>
              <textarea
                value={pastedKeywords}
                onChange={(e) => setPastedKeywords(e.target.value)}
                rows={4}
                className="mt-2 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <div className="mt-2 flex gap-2">
                <button
                  onClick={addPastedKeywords}
                  className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                >
                  Add keywords
                </button>
                <button onClick={() => setShowPaste(false)} className="rounded-lg px-4 py-2 text-sm text-slate-600 hover:bg-slate-100">
                  Cancel
                </button>
              </div>
            </div>
          )}

          {uploadReport && (
            <div className="mt-4 rounded-xl border border-blue-200 bg-blue-50 p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-900">Parse report: {uploadReport.fileName}</p>
                  <p className="text-sm text-blue-800">
                    Rows found: {uploadReport.rowsFound} · Saved: {uploadReport.keywordsSaved} · Duplicates: {uploadReport.duplicatesRemoved}
                  </p>
                  {uploadReport.warnings.map((w: string, i: number) => (
                    <p key={i} className="mt-1 text-xs text-amber-700">Warning: {w}</p>
                  ))}
                </div>
                <button onClick={() => { setUploadReport(null); setPreviewRows([]); }}>
                  <X className="h-4 w-4 text-blue-700" />
                </button>
              </div>
              {previewRows.length > 0 && (
                <div className="mt-3 max-h-64 overflow-auto rounded-lg border border-blue-200 bg-white">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600">
                      <tr>
                        <th className="px-3 py-2">Include</th>
                        <th className="px-3 py-2">Keyword</th>
                        <th className="px-3 py-2">Volume</th>
                        <th className="px-3 py-2">Intent</th>
                        <th className="px-3 py-2">Cluster</th>
                      </tr>
                    </thead>
                    <tbody>
                      {previewRows.map((row, idx) => (
                        <tr key={idx} className="border-t border-slate-100">
                          <td className="px-3 py-2">
                            <input
                              type="checkbox"
                              checked={!selectedRows.has(idx)}
                              onChange={(e) => {
                                const next = new Set(selectedRows);
                                if (e.target.checked) next.delete(idx);
                                else next.add(idx);
                                setSelectedRows(next);
                              }}
                            />
                          </td>
                          <td className="px-3 py-2 font-medium text-slate-900">{row.keyword}</td>
                          <td className="px-3 py-2">{row.volume || "-"}</td>
                          <td className="px-3 py-2">{row.intent || "-"}</td>
                          <td className="px-3 py-2">{row.cluster || "-"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              <button
                onClick={commitKeywords}
                className="mt-3 inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
              >
                <CheckCircle className="h-4 w-4" /> Save {previewRows.length - selectedRows.size} keywords
              </button>
            </div>
          )}

          <div className="mt-6 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="px-4 py-3 font-medium">Keyword</th>
                  <th className="px-4 py-3 font-medium">Volume</th>
                  <th className="px-4 py-3 font-medium">Difficulty</th>
                  <th className="px-4 py-3 font-medium">Intent</th>
                  <th className="px-4 py-3 font-medium">Cluster</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((k) => (
                  <tr key={k.id} className="border-t border-slate-100 hover:bg-slate-50">
                    <td className="px-4 py-3 font-medium text-slate-900">{k.keyword}</td>
                    <td className="px-4 py-3 text-slate-600">{k.volume ?? "-"}</td>
                    <td className="px-4 py-3 text-slate-600">{k.difficulty ?? "-"}</td>
                    <td className="px-4 py-3 text-slate-600">{k.intent || "-"}</td>
                    <td className="px-4 py-3 text-slate-600">{k.cluster?.name || "-"}</td>
                    <td className="px-4 py-3">
                      <select
                        value={k.status}
                        onChange={(e) => updateKeywordStatus(k.id, e.target.value)}
                        className="rounded-md border border-slate-300 px-2 py-1 text-xs"
                      >
                        <option value="new">New</option>
                        <option value="in_progress">In progress</option>
                        <option value="done">Done</option>
                        <option value="skipped">Skipped</option>
                      </select>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setGenerateKeyword(k)}
                          className="rounded-md bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 hover:bg-blue-100"
                        >
                          Make content
                        </button>
                        <button onClick={() => deleteKeyword(k.id)} className="text-slate-400 hover:text-red-600">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && !loading && (
                  <tr>
                    <td colSpan={7} className="px-4 py-10 text-center text-sm text-slate-500">
                      No keywords yet. Upload a file or paste a list above.
                      <br />
                      <span className="text-xs text-slate-400">Sample: waterproofing services in surat, terrace leak repair, bathroom waterproofing cost</span>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab !== "keywords" && (
        <div className="mt-10 rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 p-10 text-center">
          <p className="font-medium text-slate-700">{tab.charAt(0).toUpperCase() + tab.slice(1)} tab</p>
          <p className="mt-1 text-sm text-slate-500">This module is in the build queue. Use the Keywords tab to start.</p>
        </div>
      )}

      {generateKeyword && (
        <GenerateModal
          project={project}
          keyword={generateKeyword}
          keywords={keywords}
          onClose={() => setGenerateKeyword(null)}
          onDone={() => {
            setGenerateKeyword(null);
            loadKeywords();
          }}
        />
      )}
    </div>
  );
}

function GenerateModal({
  project,
  keyword,
  keywords,
  onClose,
  onDone,
}: {
  project: Project;
  keyword: Keyword;
  keywords: Keyword[];
  onClose: () => void;
  onDone: () => void;
}) {
  const [contentType, setContentType] = useState("blog_post");
  const [targetWords, setTargetWords] = useState(1200);
  const [tone, setTone] = useState("simple English");
  const [extra, setExtra] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [progress, setProgress] = useState(0);
  const [stageLabel, setStageLabel] = useState("");
  const [stageMessage, setStageMessage] = useState("");
  const [finishedId, setFinishedId] = useState<number | null>(null);

  const suggestions = useMemo(() => {
    const sameCluster = keywords.filter(
      (k) => k.cluster?.name === keyword.cluster?.name && k.id !== keyword.id
    );
    return sameCluster.slice(0, 3).map((k) => k.keyword);
  }, [keywords, keyword]);

  const [secondaries, setSecondaries] = useState(suggestions);

  async function generate() {
    setLoading(true);
    setError("");
    setProgress(0);
    setStageLabel("Starting...");
    setStageMessage("");
    setFinishedId(null);
    try {
      const res = await fetch(`/api/projects/${project.id}/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          keywordId: keyword.id,
          contentType,
          targetWords,
          tone,
          extraInstructions: extra,
          secondaryKeywords: secondaries,
        }),
      });
      const data = await res.json();
      if (!data.success) {
        setError(data.message || "Could not start generation.");
        setLoading(false);
        return;
      }

      // Run one stage per request until the article is done.
      const generationId = data.generationId;
      for (let i = 0; i < 40; i++) {
        const stepRes = await fetch(`/api/generations/${generationId}/step`, { method: "POST" });
        const step = await stepRes.json();
        if (!step.success) {
          throw new Error(step.message || "Stage failed.");
        }
        setProgress(step.progress ?? 0);
        setStageLabel(step.stageLabel || step.stage || "");
        setStageMessage(step.message || "");
        if (step.done) {
          setFinishedId(step.contentId ?? null);
          setProgress(100);
          onDone();
          if (step.contentId) {
            window.open(`/contents/${step.contentId}`, "_blank");
          }
          break;
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  const showProgress = loading || finishedId !== null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-2xl max-h-[90vh] overflow-auto rounded-2xl bg-white p-6 shadow-xl">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-900">Make content</h2>
          <button onClick={onClose}>
            <X className="h-5 w-5 text-slate-500" />
          </button>
        </div>
        <p className="mt-1 text-sm text-slate-600">Keyword: <span className="font-medium text-slate-900">{keyword.keyword}</span></p>

        {error && <p className="mt-4 rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700">{error}</p>}

        {showProgress ? (
          <div className="mt-6">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-slate-900">
                {finishedId !== null ? "Article is ready." : stageLabel || "Working..."}
              </span>
              <span className="text-slate-600">{progress}%</span>
            </div>
            <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-slate-200">
              <div
                className="h-full rounded-full bg-blue-600 transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
            {stageMessage && !finishedId && (
              <p className="mt-3 text-sm text-slate-600">{stageMessage}</p>
            )}
            {loading && (
              <p className="mt-3 flex items-center gap-2 text-sm text-slate-500">
                <Loader2 className="h-4 w-4 animate-spin" />
                Writing your article, one stage at a time. Keep this window open.
              </p>
            )}
            {finishedId !== null && (
              <div className="mt-4 flex items-center gap-3">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <p className="text-sm text-slate-700">
                  Done. The article opened in a new tab.
                </p>
                <a
                  href={`/contents/${finishedId}`}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                >
                  Open article
                </a>
                <button
                  onClick={onClose}
                  className="rounded-lg px-4 py-2 text-sm text-slate-600 hover:bg-slate-100"
                >
                  Close
                </button>
              </div>
            )}
          </div>
        ) : (
          <>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-slate-700">Content type</label>
                <select
                  value={contentType}
                  onChange={(e) => setContentType(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                >
                  <option value="blog_post">Blog post</option>
                  <option value="article">Long-form article / pillar</option>
                  <option value="landing_page">Landing page</option>
                  <option value="service_page">Service page</option>
                  <option value="faq_page">FAQ page</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700">Word count: {targetWords}</label>
                <input
                  type="range"
                  min={1000}
                  max={3000}
                  step={100}
                  value={targetWords}
                  onChange={(e) => setTargetWords(Number(e.target.value))}
                  className="mt-3 w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700">Tone</label>
                <select
                  value={tone}
                  onChange={(e) => setTone(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                >
                  <option value="simple English">Simple English</option>
                  <option value="friendly">Friendly</option>
                  <option value="professional">Professional</option>
                  <option value="persuasive">Persuasive</option>
                  <option value="expert">Expert</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700">Secondary keywords</label>
                <input
                  value={secondaries.join(", ")}
                  onChange={(e) => setSecondaries(e.target.value.split(",").map((s) => s.trim()))}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  placeholder=" terrace waterproofing, bathroom leak repair"
                />
              </div>
            </div>
            <div className="mt-4">
              <label className="block text-sm font-medium text-slate-700">Extra instructions</label>
              <textarea
                value={extra}
                onChange={(e) => setExtra(e.target.value)}
                rows={3}
                maxLength={500}
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                placeholder="Mention monsoon season, include a cost table, keep paragraphs short..."
              />
              <p className="mt-1 text-xs text-slate-500">{extra.length}/500</p>
            </div>

            <div className="mt-6 flex items-center justify-between">
              <p className="text-sm text-slate-600">Estimated: 1 credit · ~2-3 minutes</p>
              <button
                onClick={generate}
                disabled={loading}
                className="flex items-center gap-2 rounded-lg bg-blue-600 px-6 py-2.5 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-70"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                Generate
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
