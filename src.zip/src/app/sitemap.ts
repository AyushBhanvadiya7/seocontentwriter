import type { MetadataRoute } from "next";

// Served at /sitemap.xml — the list of public pages for Google.
const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const entry = (
    path: string,
    priority: number,
    changeFrequency: "weekly" | "monthly"
  ): MetadataRoute.Sitemap[number] => ({
    url: `${APP_URL}${path}`,
    lastModified: now,
    changeFrequency,
    priority,
  });

  return [
    entry("/", 1, "weekly"),
    entry("/pricing", 0.8, "monthly"),
    entry("/login", 0.5, "monthly"),
    entry("/register", 0.6, "monthly"),
    entry("/terms", 0.3, "monthly"),
    entry("/privacy", 0.3, "monthly"),
    entry("/refunds", 0.3, "monthly"),
    entry("/contact", 0.5, "monthly"),
  ];
}
