import Link from "next/link";
import { redirect } from "next/navigation";
import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { contents, projects } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { FileText, ExternalLink } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function LibraryPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const userProjects = await db.query.projects.findMany({
    where: eq(projects.userId, user.id),
    columns: { id: true },
  });
  const projectIds = userProjects.map((p) => p.id);

  const items = await db.query.contents.findMany({
    where: eq(contents.projectId, projectIds[0] || 0),
    with: { project: true, keyword: true },
    orderBy: desc(contents.createdAt),
    limit: 100,
  });

  // Simple authorization filter (if no projects, empty)
  const visible = projectIds.includes(items[0]?.projectId || 0) ? items : [];

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="text-2xl font-semibold text-slate-900">Content library</h1>
      <p className="text-sm text-slate-600">All your generated articles, exports and statuses.</p>

      {visible.length === 0 ? (
        <div className="mt-8 rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 p-10 text-center">
          <p className="text-slate-600">No content yet.</p>
          <p className="mt-1 text-sm text-slate-500">Generate your first article from a project workspace.</p>
        </div>
      ) : (
        <div className="mt-6 divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white">
          {visible.map((item) => (
            <div key={item.id} className="flex flex-col gap-2 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <Link href={`/contents/${item.id}`} className="font-medium text-slate-900 hover:text-blue-700">
                  {item.title || item.h1 || "Untitled"}
                </Link>
                <p className="text-xs text-slate-500">
                  {item.keyword?.keyword} · {item.wordCount} words · Score {item.qualityScore} ·{" "}
                  <span className="inline-flex rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium capitalize">
                    {item.status}
                  </span>
                </p>
              </div>
              <Link
                href={`/contents/${item.id}`}
                className="inline-flex items-center gap-1.5 text-sm font-medium text-blue-600 hover:underline"
              >
                Open <ExternalLink className="h-3.5 w-3.5" />
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
