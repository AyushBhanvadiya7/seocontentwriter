// Prompt builders for every generation stage.
// Each prompt has three parts: ROLE (who the AI is),
// RULES (what to do and what never to do),
// SCHEMA (the exact JSON shape to return, with an example).
// Schemas matter: the old code did JSON.parse on free-form text,
// which always failed and produced empty articles.

export interface ProjectContext {
  keyword: string;
  country: string;
  city?: string | null;
  language?: string | null;
  industry?: string | null;
  audience?: string | null;
  businessDescription?: string | null;
  productsServices?: string | null;
  competitors?: string | null;
  contentType: string;
  targetWords: number;
  tone: string;
  secondaryKeywords: string[];
  extraInstructions?: string | null;
  brandVoice?: {
    tone?: string | null;
    readingLevel?: string | null;
    mustUseWords?: unknown;
    bannedWords?: unknown;
    authorName?: string | null;
    authorBio?: string | null;
    sampleWriting?: string | null;
  } | null;
}

// Shared: brand voice + project detail, included in every prompt.
function brandBlock(ctx: ProjectContext): string {
  const bv = ctx.brandVoice;
  const lines: string[] = [];
  if (ctx.industry) lines.push(`Industry: ${ctx.industry}`);
  if (ctx.audience) lines.push(`Target audience: ${ctx.audience}`);
  if (ctx.city) lines.push(`Target city: ${ctx.city}`);
  lines.push(`Target country: ${ctx.country}`);
  lines.push(`Language: ${ctx.language === "hi" ? "Hindi" : "English"}`);
  if (ctx.businessDescription) {
    lines.push(`Business: ${ctx.businessDescription.slice(0, 900)}`);
  }
  if (ctx.productsServices) {
    lines.push(`Products/Services: ${String(ctx.productsServices).slice(0, 600)}`);
  }
  if (bv?.tone) lines.push(`Brand tone: ${bv.tone}`);
  if (bv?.readingLevel) lines.push(`Reading level: ${bv.readingLevel}`);
  if (bv?.authorName) lines.push(`Author name: ${bv.authorName}`);

  const must = (bv?.mustUseWords as string[]) || [];
  if (must.length) lines.push(`Words that MUST appear: ${must.slice(0, 15).join(", ")}`);

  const banned = (bv?.bannedWords as string[]) || [];
  if (banned.length) lines.push(`Words that must NEVER appear: ${banned.slice(0, 20).join(", ")}`);

  return lines.join("\n");
}

// Shared: rules that keep the writing human-sounding.
const HUMAN_WRITING_RULES = `
WRITING RULES (never break these):
1. Write like a knowledgeable human talking to one person — not like a report or a brochure.
2. BANNED phrases (never use): "delve into", "tapestry", "game-changer", "in today's fast-paced world", "furthermore", "moreover", "in conclusion", "it is important to note", "navigate the landscape", "unlock the potential", "in the realm of", "testament to", "when it comes to".
3. Never start two consecutive sentences with the same word.
4. Use short sentences mixed with medium ones. Never write a 40-word sentence.
5. No in-paragraph bolding. Bold only inside table headers or a term being defined.
6. No filler paragraphs. Every paragraph must add new information.
7. Prefer concrete numbers, names and examples over vague adjectives.
8. Do not repeat the primary keyword more than once per 150 words.`;

// STAGE 2 — RESEARCH

export function researchPrompt(ctx: ProjectContext) {
  const system = `You are a senior SEO research analyst with 12 years of experience. You analyse search intent, competitor coverage and content gaps before any article is written.

${HUMAN_WRITING_RULES}

YOUR OUTPUT MUST BE VALID JSON. No text before or after the JSON. No markdown code fences.
Every string value must be plain text (no markdown, no bullet characters inside strings).`;

  const user = `Research the keyword: "${ctx.keyword}"

${brandBlock(ctx)}

Return JSON with EXACTLY this shape:

{
  "search_intent": "one of: informational | commercial | transactional | navigational",
  "intent_summary": "2-3 sentences: what exactly does this searcher want to get from this page? Write it in plain English.",
  "reader_profile": "1 sentence describing who this person is and what they already know.",
  "top_results": [
    { "rank": 1, "title": "a realistic page title that would rank", "url": "https://example.com/page", "angle": "what angle this page takes" }
  ],
  "people_also_ask": ["question 1", "question 2", "question 3", "question 4", "question 5"],
  "related_searches": ["term 1", "term 2", "term 3", "term 4", "term 5"],
  "facts": [
    { "statement": "a specific, checkable fact or benchmark relevant to this topic", "why_it_matters": "why the reader cares" }
  ],
  "statistics": [
    { "metric": "name of the metric", "value": "number or range with unit", "context": "what it means" }
  ],
  "definitions": [
    { "term": "a term the reader may not know", "plain_english": "explain it in under 15 words" }
  ],
  "content_gaps": ["what top-ranking pages FAIL to explain — this is where we win"],
  "common_mistakes": ["mistake buyers or readers commonly make"],
  "buying_criteria": ["what the reader should compare before choosing"],
  "local_facts": ["anything specific to ${ctx.city || ctx.country} — regulations, pricing norms, market habits"],
  "risks": ["what could go wrong if the reader chooses badly"],
  "freshness_note": "what is changing in this topic during 2026-2027"
}

REQUIREMENTS:
- top_results: exactly 5 items. Use REAL-SOUNDING titles and plausible URLs for this industry.
- people_also_ask: exactly 5 questions — these become our FAQ section. Write them the way a real person types them.
- facts: at least 6 items. Be specific (numbers, ranges, timeframes). If unsure, give a realistic industry range and say "typically" — never invent a fake statistic with a named source.
- statistics: at least 4 items.
- definitions: 3 to 5 items.
- content_gaps: at least 4 items. This is the most valuable part — be sharp.
- local_facts: at least 2 items if a city/country is given, else return [].

Keyword: "${ctx.keyword}"`;

  return { system, user };
}

// STAGE 3 — OUTLINE

export function outlinePrompt(ctx: ProjectContext, research: Record<string, unknown>) {
  const system = `You are a content strategist. You turn research into a tight article outline that a writer can follow section by section.

${HUMAN_WRITING_RULES}

YOUR OUTPUT MUST BE VALID JSON. No text before or after. No code fences.`;

  const user = `Build a detailed outline for a ${ctx.contentType} about "${ctx.keyword}".

${brandBlock(ctx)}

TARGET LENGTH: ${ctx.targetWords} words. Split that across the sections below
(each section's target_words must add up to roughly ${ctx.targetWords}).

RESEARCH WE ALREADY HAVE (use it — do not invent a different topic):
${JSON.stringify(research).slice(0, 4000)}

Return JSON with EXACTLY this shape:

{
  "h1": "the H1 title — must contain the primary keyword, under 65 characters, and must NOT end with the same word pattern as typical AI titles",
  "angle": "one sentence: the unique angle this article takes that competitors do not",
  "sections": [
    {
      "heading": "H2 heading in sentence case",
      "level": 2,
      "target_words": 250,
      "purpose": "what this section must achieve for the reader",
      "key_points": ["specific point to cover", "another point"],
      "use_research": ["which research item feeds this section"]
    }
  ],
  "faq_questions": ["question 1", "question 2", "question 3", "question 4", "question 5"],
  "closing_cta": "what the reader should do at the end (specific to this business)",
  "total_target_words": ${ctx.targetWords}
}

REQUIREMENTS:
- sections: between 5 and 9 items. Order them the way a real reader thinks.
- Each section must have 3 to 5 key_points. Never repeat a point across sections.
- At least 2 sections must directly attack the "content_gaps" from the research.
- At least 1 section must be comparison-oriented (a table works well here) if buying_criteria exist.
- headings must be interesting and specific — NOT generic like "Introduction", "Conclusion", "Overview", "Why It Matters" used alone.
- faq_questions: exactly 5. These must be different from the people_also_ask if possible, and must be genuinely answerable in 40-80 words.
- Do not add an "Introduction" section and a "Conclusion" section as plain headings — the writer handles opening and closing.
- Set "level": 2 for main sections.

Keyword: "${ctx.keyword}"`;

  return { system, user };
}

// STAGE 4 — WRITER (one section per call)

export function writerSectionPrompt(
  ctx: ProjectContext,
  research: Record<string, unknown>,
  outline: { h1?: string; angle?: string },
  section: {
    heading: string;
    target_words: number;
    purpose?: string;
    key_points?: string[];
    use_research?: string[];
  },
  sectionIndex: number,
  totalSections: number,
  previousHeads: string[]
) {
  const system = `You are a senior writer for a respected trade publication. You have 12 years of experience and you write like a human, not like a content mill.

${HUMAN_WRITING_RULES}

OUTPUT FORMAT:
- Return MARKDOWN only. No preamble like "Here is the section".
- Start directly with the "## " heading given to you. Use the EXACT heading text you are given.
- Use "### " for sub-points inside the section when it helps.
- Use a markdown table when comparing things.
- Use "- " bullet lists for genuine lists only. Never turn a normal paragraph into bullets.
- Do NOT write the article title (H1) — only this section.
- Do NOT add any closing summary like "In conclusion".
- Length: within 15% of the target word count. Count your words before answering.`;

  const user = `ARTICLE
Primary keyword: ${ctx.keyword}
Title (H1): ${outline.h1 || ctx.keyword}
Overall angle: ${outline.angle || "practical, experience-based guide"}
Content type: ${ctx.contentType}
Tone: ${ctx.tone}

${brandBlock(ctx)}

SECTION ${sectionIndex + 1} OF ${totalSections}
Heading to use: ## ${section.heading}
Target length: about ${section.target_words} words
Purpose of this section: ${section.purpose || "inform and help the reader decide"}
Points that MUST be covered:
${(section.key_points || []).map((p) => `- ${p}`).join("\n") || "- decide sensible points yourself"}

RESEARCH TO USE (pick only what fits this section — do not dump everything):
${JSON.stringify({
  facts: (research.facts as unknown[])?.slice(0, 6),
  statistics: (research.statistics as unknown[])?.slice(0, 5),
  definitions: (research.definitions as unknown[])?.slice(0, 4),
  common_mistakes: (research.common_mistakes as unknown[])?.slice(0, 4),
  buying_criteria: (research.buying_criteria as unknown[])?.slice(0, 4),
  local_facts: (research.local_facts as unknown[])?.slice(0, 3),
  risks: (research.risks as unknown[])?.slice(0, 3),
}).slice(0, 3000)}

SECTIONS ALREADY WRITTEN (do not repeat their content or their headings):
${previousHeads.length ? previousHeads.map((h) => `- ${h}`).join("\n") : "- (this is the first section)"}

Now write ONLY this section.`;

  return { system, user };
}

export function writerOpeningPrompt(
  ctx: ProjectContext,
  research: Record<string, unknown>,
  outline: { h1?: string; angle?: string },
  firstSectionHeading: string
) {
  const system = `You are a senior writer. You write article openings that make a reader stay.

${HUMAN_WRITING_RULES}

OUTPUT FORMAT:
- Markdown only. No preamble, no title, no H1.
- 2 to 4 short paragraphs. Total 90-160 words.
- The FIRST sentence must make a specific claim, give a specific number, or describe a specific situation. NEVER start with "In today's world", "In the world of X", "When it comes to X", or a dictionary-style definition.
- Do not use the words "Introduction", "Overview" or "Guide" in the opening.
- End with one sentence that tells the reader what the rest of the article will give them — without saying "in this article we will".`;

  const user = `Write the opening (intro) for this article.

Primary keyword: ${ctx.keyword}
Title (H1): ${outline.h1 || ctx.keyword}
Angle: ${outline.angle || "practical, experience-based guide"}
Audience: ${ctx.audience || "business decision makers"}
Tone: ${ctx.tone}

${brandBlock(ctx)}

The next section heading will be: "${firstSectionHeading}"
So the opening must lead naturally into that.

Useful research:
${JSON.stringify({
  intent_summary: research.intent_summary,
  reader_profile: research.reader_profile,
  statistics: (research.statistics as unknown[])?.slice(0, 4),
  common_mistakes: (research.common_mistakes as unknown[])?.slice(0, 3),
  risks: (research.risks as unknown[])?.slice(0, 2),
  local_facts: (research.local_facts as unknown[])?.slice(0, 2),
}).slice(0, 2000)}

Write the opening now.`;

  return { system, user };
}

export function writerClosingPrompt(
  ctx: ProjectContext,
  outline: { h1?: string; closing_cta?: string },
  sectionHeads: string[]
) {
  const system = `You are a senior writer. You write closings that feel like advice from a person, not a summary robot.

${HUMAN_WRITING_RULES}

OUTPUT FORMAT:
- Markdown only. No preamble.
- Start with "## " and a specific heading (never "Conclusion", "Final Thoughts" alone, or "Summary"). Make the heading about the decision the reader now faces.
- 2 to 3 short paragraphs, then optionally 3-4 bullet points of "what to do next".
- Do NOT summarise every section you already wrote. Instead, give the reader a decision framework or the single most important next step.
- End with a clear, specific call to action.`;

  const user = `Write the closing section of this article.

Primary keyword: ${ctx.keyword}
Title (H1): ${outline.h1 || ctx.keyword}
Suggested action for the reader: ${outline.closing_cta || "contact the business for a quote"}

${brandBlock(ctx)}

Sections already written:
${sectionHeads.map((h) => `- ${h}`).join("\n")}

Write the closing now.`;

  return { system, user };
}

// STAGE 5 — PACKAGING (meta + FAQ + image prompts, one call)

export function packagingPrompt(
  ctx: ProjectContext,
  research: Record<string, unknown>,
  outline: { h1?: string; faq_questions?: string[] },
  article: string
) {
  const system = `You are an SEO editor who prepares a finished article for publishing. You write meta tags, FAQ answers and image briefs.

${HUMAN_WRITING_RULES}

YOUR OUTPUT MUST BE VALID JSON. No text before or after. No code fences.`;

  const user = `Prepare the publishing package for this article.

Primary keyword: "${ctx.keyword}"
Content type: ${ctx.contentType}

${brandBlock(ctx)}

ARTICLE TITLE: ${outline.h1 || ctx.keyword}

Questions that need real answers (these become the FAQ section):
${(outline.faq_questions || []).map((q) => `- ${q}`).join("\n") || "- decide 5 sensible questions yourself"}

ARTICLE (for context — read it, then answer the FAQ from it):
${article.slice(0, 9000)}

Return JSON with EXACTLY this shape:

{
  "meta_title": "50-60 characters. Contains the primary keyword naturally. NO clickbait.",
  "meta_description": "145-158 characters. Mentions a concrete benefit AND a concrete detail (number, timeframe or city). Ends without a full stop or ends with one — either is fine.",
  "slug": "lowercase-words-with-hyphens, max 5 words, no stop words",
  "h1": "the final H1 (max 65 chars). May improve the original if it is weak.",
  "tags": ["3 to 6 short topical tags"],
  "category": "single category name from the industry",
  "faq": [
    {
      "question": "the exact question text",
      "answer": "40 to 80 words. A REAL answer that a human would accept. Use a specific number or detail from the article. Never write 'it depends' without immediately saying what it depends on. Never write 'based on industry best practices'."
    }
  ],
  "image_prompts": [
    {
      "placement": "after the intro | mid-article | near the pricing table",
      "prompt": "a detailed text-to-image prompt. Name the setting, the subject, the lighting, the camera angle and the mood. No text in the image.",
      "negative_prompt": "what to avoid",
      "alt_text": "SEO alt text under 125 characters, describing the image",
      "file_name": "keyword-based-name.webp",
      "caption": "a one-line caption for the image"
    }
  ],
  "internal_link_suggestions": [
    { "anchor_text": "natural phrase from the article", "suggested_target_topic": "what kind of page it should link to" }
  ]
}

REQUIREMENTS:
- faq: EXACTLY one answer for EVERY question listed above. This is the single most important part of your output. Every answer must be different and specific.
- image_prompts: exactly 3 items (intro, mid-article, and one supporting a table or comparison).
- meta_title and meta_description must NOT be identical to the H1.
- internal_link_suggestions: 3 to 5 items.

Keyword: "${ctx.keyword}"`;

  return { system, user };
}

// Helper: extract JSON from an AI reply.
// The AI sometimes wraps JSON in ```json fences, or adds text around it.
export function safeJsonParse<T>(text: string, fallback: T): T {
  if (!text) return fallback;

  // 1. Try directly.
  try {
    return JSON.parse(text) as T;
  } catch {
    // Continue to the next strategy.
  }

  // 2. Strip ```json ... ``` fences and try again.
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced?.[1]) {
    try {
      return JSON.parse(fenced[1].trim()) as T;
    } catch {
      // Continue to the next strategy.
    }
  }

  // 3. Take the span from the first { to the last }.
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start !== -1 && end > start) {
    try {
      return JSON.parse(text.slice(start, end + 1)) as T;
    } catch {
      // Continue to the fallback.
    }
  }

  console.error("JSON parse failed. AI reply was:\n", text.slice(0, 600));
  return fallback;
}