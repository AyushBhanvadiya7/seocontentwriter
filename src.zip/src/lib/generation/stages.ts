import { db } from "@/db";
import { briefs, linkLibrary } from "@/db/schema";
import { eq } from "drizzle-orm";
import { LLMProvider } from "@/lib/llm/provider";
import { fetchSerp } from "@/lib/serp";
import { 
  researchPrompt,
  outlinePrompt,
  writerOpeningPrompt,
  writerSectionPrompt,
  writerClosingPrompt,
  packagingPrompt,
  safeJsonParse,
  type ProjectContext,
} from "./prompts";

// The 5 generation stages. Each HTTP request runs exactly ONE stage,
// so no request ever hits the serverless timeout. The browser calls
// the step API again and again until every stage is done.

export const STAGES = ["research", "outline", "writing", "packaging", "finalizing"] as const;
export type StageName = (typeof STAGES)[number];

// Labels shown in the progress bar.
export const STAGE_LABELS: Record<StageName, string> = {
  research: "Researching — understanding what the reader wants",
  outline: "Outlining — building the article structure",
  writing: "Writing — sections are being written",
  packaging: "Packaging — meta tags, FAQ and image prompts",
  finalizing: "Finalizing — checking and saving",
};

// Brief shape. Kept loose because researchData/outline come from jsonb.
export interface BriefShape {
  id: number;
  projectId: number;
  keywordId: number;
  contentType: string;
  audience?: string | null;
  secondaryKeywords?: unknown;
  targetWords?: number | null;
  tone?: string | null;
  extraInstructions?: string | null;
  researchData?: Record<string, unknown> | null;
  outline?: Record<string, unknown> | null;
  status?: string | null;
}

export interface StageContext {
  brief: BriefShape;
  ctx: ProjectContext;
  provider: LLMProvider;
}

// Builds the project context every stage needs.
export async function buildContext(
  brief: BriefShape,
  project: {
    id: number;
    targetCountry?: string | null;
    targetCity?: string | null;
    language?: string | null;
    industry?: string | null;
    audience?: string | null;
    businessDescription?: string | null;
    productsServices?: string | null;
    competitors?: string | null;
  },
  keyword: { keyword: string },
  brandVoice: Record<string, unknown> | null
): Promise<ProjectContext> {
  return {
    keyword: keyword.keyword,
    country: project.targetCountry || "IN",
    city: project.targetCity,
    language: project.language || "en",
    industry: project.industry,
    audience: project.audience || brief.audience || null,
    businessDescription: project.businessDescription,
    productsServices: project.productsServices,
    competitors: project.competitors,
    contentType: brief.contentType,
    targetWords: brief.targetWords || 1200,
    tone: brief.tone || "simple English",
    secondaryKeywords: (brief.secondaryKeywords as string[]) || [],
    extraInstructions: brief.extraInstructions,
    brandVoice: brandVoice
      ? {
          tone: (brandVoice.tone as string) || null,
          readingLevel: (brandVoice.readingLevel as string) || null,
          mustUseWords: brandVoice.mustUseWords,
          bannedWords: brandVoice.bannedWords,
          authorName: (brandVoice.authorName as string) || null,
          authorBio: (brandVoice.authorBio as string) || null,
          sampleWriting: (brandVoice.sampleWriting as string) || null,
        }
      : null,
  };
}

// STAGE 2 — RESEARCH

export async function runResearchStage(sc: StageContext) {
  const { system, user } = researchPrompt(sc.ctx);
  const res = await sc.provider.complete({
    messages: [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
    jsonMode: true,
    temperature: 0.4,
    maxTokens: 4000,
  });

  const data = safeJsonParse<Record<string, unknown>>(res.text, {});

  // Never let an empty answer pass silently to the next stage.
  if (!data.intent_summary && !data.people_also_ask) {
    throw new Error(
      "Research stage returned an empty answer. Retry, or set GEMINI_MODEL to 'gemini-2.5-flash'."
    );
  }
  
  // Replace AI-guessed Google data with real SERP results when a key exists.
  // Without a key (or on any SERP error) the AI data stays, so nothing breaks.
  try {
    const serp = await fetchSerp(sc.ctx.keyword);
    if (serp && serp.topResults.length > 0) {
      data.top_results = serp.topResults.map((r) => ({
        rank: r.rank,
        title: r.title,
        url: r.url,
        angle: r.snippet,
      }));
      if (serp.peopleAlsoAsk.length > 0) data.people_also_ask = serp.peopleAlsoAsk;
      if (serp.relatedSearches.length > 0) data.related_searches = serp.relatedSearches;
      data.serp_source = "serper-live";
    } else {
      data.serp_source = "ai-fallback";
    }
  } catch (err) {
    data.serp_source = "ai-fallback";
    data.serp_error = err instanceof Error ? err.message : "SERP lookup failed.";
  }

  await db
    .update(briefs)
    .set({ researchData: data, status: "outline" })
    .where(eq(briefs.id, sc.brief.id));

  return {
    tokensIn: res.tokensIn,
    tokensOut: res.tokensOut,
    preview: String(data.intent_summary || "").slice(0, 220),
  };
}

// STAGE 3 — OUTLINE

export async function runOutlineStage(sc: StageContext) {
  const research = (sc.brief.researchData || {}) as Record<string, unknown>;
  const { system, user } = outlinePrompt(sc.ctx, research);

  const res = await sc.provider.complete({
    messages: [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
    jsonMode: true,
    temperature: 0.6,
    maxTokens: 3500,
  });

  const data = safeJsonParse<{
    h1?: string;
    angle?: string;
    sections?: Array<{ heading: string; target_words?: number; purpose?: string; key_points?: string[] }>;
    faq_questions?: string[];
    closing_cta?: string;
  }>(res.text, {});

  if (!data.sections || !Array.isArray(data.sections) || data.sections.length < 3) {
    throw new Error("Outline stage returned no sections. Retry.");
  }

  // Draft lives inside the outline itself (no new column needed).
  const outlineWithDraft = {
    ...data,
    _draft: { written: [] as Array<{ heading: string; markdown: string }> },
  };

  await db
    .update(briefs)
    .set({ outline: outlineWithDraft, status: "writing" })
    .where(eq(briefs.id, sc.brief.id));

  return {
    tokensIn: res.tokensIn,
    tokensOut: res.tokensOut,
    preview: `${data.sections.length} sections planned: ${data.h1 || ""}`.slice(0, 240),
  };
}

// STAGE 4 — WRITER (one step = one piece, so nothing ever times out).
// Order: [opening] -> [section 1..N] -> [FAQ] -> [closing].
// All pieces share one queue, so the progress bar can show "5 / 9 written".

interface DraftShape {
  written: Array<{ heading: string; markdown: string }>;
}

export async function runWritingStage(sc: StageContext) {
  const outline = (sc.brief.outline || {}) as {
    h1?: string;
    angle?: string;
    sections?: Array<{ heading: string; target_words?: number; purpose?: string; key_points?: string[] }>;
    faq_questions?: string[];
    closing_cta?: string;
    _draft?: DraftShape;
  };

  const research = (sc.brief.researchData || {}) as Record<string, unknown>;
  const sections = outline.sections || [];
  const written: Array<{ heading: string; markdown: string }> = outline._draft?.written || [];

  // Full plan: 1 opening + N sections + 1 FAQ + 1 closing.
  const totalPieces = 1 + sections.length + 1 + 1;
  const done = written.length;

  let pieceTitle = "";
  let markdown = "";

  if (done === 0) {
    // Piece 1: Opening.
    const p = writerOpeningPrompt(sc.ctx, research, outline, sections[0]?.heading || "Overview");
    const res = await sc.provider.complete({
      messages: [
        { role: "system", content: p.system },
        { role: "user", content: p.user },
      ],
      temperature: 0.75,
      maxTokens: 1200,
    });
    markdown = res.text.trim();
    pieceTitle = "Opening";
    return await savePiece(sc, outline, written, pieceTitle, markdown, sections.length + 3, done + 1, totalPieces, res.tokensIn, res.tokensOut);
  }

  if (done >= 1 && done <= sections.length) {
    // Pieces 2..N+1: Sections.
    const idx = done - 1;
    const section = sections[idx];
    const p = writerSectionPrompt(
      sc.ctx,
      research,
      outline,
      {
        heading: section.heading,
        target_words: section.target_words || 250,
        purpose: section.purpose,
        key_points: section.key_points,
      },
      idx,
      sections.length,
      written.map((w) => w.heading)
    );
    const res = await sc.provider.complete({
      messages: [
        { role: "system", content: p.system },
        { role: "user", content: p.user },
      ],
      temperature: 0.75,
      maxTokens: Math.min((section.target_words || 250) * 3 + 800, 8000),
    });
    markdown = res.text.trim();

    // AI forgot the heading? Add it ourselves.
    if (!markdown.startsWith("##")) {
      markdown = `## ${section.heading}\n\n${markdown}`;
    }
    pieceTitle = section.heading;
    return await savePiece(sc, outline, written, pieceTitle, markdown, sections.length + 3, done + 1, totalPieces, res.tokensIn, res.tokensOut);
  }

  if (done === sections.length + 1) {
    // Piece: FAQ placeholder (real answers come from the packaging stage,
    // so the questions are parked here as headings for now).
    const faqQs = outline.faq_questions || [];
    markdown = `## Frequently asked questions\n\n${faqQs.map((q) => `### ${q}\n\n_(answer added in the next step)_`).join("\n\n")}`;
    pieceTitle = "FAQ";
    return await savePiece(sc, outline, written, pieceTitle, markdown, sections.length + 3, done + 1, totalPieces, 0, 0);
  }

  // Last piece: Closing.
  const p = writerClosingPrompt(sc.ctx, outline, written.map((w) => w.heading));
  const res = await sc.provider.complete({
    messages: [
      { role: "system", content: p.system },
      { role: "user", content: p.user },
    ],
    temperature: 0.7,
    maxTokens: 1500,
  });
  markdown = res.text.trim();
  pieceTitle = "Closing";

  const result = await savePiece(
    sc,
    outline,
    written,
    pieceTitle,
    markdown,
    sections.length + 3,
    done + 1,
    totalPieces,
    res.tokensIn,
    res.tokensOut
  );

  // All pieces done -> next stage.
  await db.update(briefs).set({ status: "packaging" }).where(eq(briefs.id, sc.brief.id));
  return result;
}

// Appends one piece (opening/section/closing) to the draft.
async function savePiece(
  sc: StageContext,
  outline: Record<string, unknown> & { _draft?: DraftShape; sections?: unknown[] },
  written: Array<{ heading: string; markdown: string }>,
  heading: string,
  markdown: string,
  _plannedSections: number,
  doneCount: number,
  totalPieces: number,
  tokensIn: number,
  tokensOut: number
) {
  const updated = { ...outline, _draft: { written: [...written, { heading, markdown }] } };
  await db.update(briefs).set({ outline: updated }).where(eq(briefs.id, sc.brief.id));

  const totalWords = [...written, { heading, markdown }]
    .map((w) => countWords(w.markdown))
    .reduce((a, b) => a + b, 0);

  return {
    tokensIn,
    tokensOut,
    preview: `${doneCount} / ${totalPieces} pieces written — ${totalWords} words so far`,
    wordsSoFar: totalWords,
  };
}

// STAGE 5 — PACKAGING (meta + FAQ answers + image prompts)

export async function runPackagingStage(sc: StageContext) {
  const outline = (sc.brief.outline || {}) as {
    h1?: string;
    faq_questions?: string[];
    _draft?: DraftShape;
  };
  const research = (sc.brief.researchData || {}) as Record<string, unknown>;
  const written = outline._draft?.written || [];
  const article = written.map((w) => w.markdown).join("\n\n");

  const { system, user } = packagingPrompt(sc.ctx, research, outline, article);
  const res = await sc.provider.complete({
    messages: [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
    jsonMode: true,
    temperature: 0.5,
    maxTokens: 4000,
  });

  const data = safeJsonParse<Record<string, unknown>>(res.text, {});

  if (!data.meta_title) {
    throw new Error("Packaging stage returned no meta title. Retry.");
  }

  await db
    .update(briefs)
    .set({
      outline: { ...outline, _packaging: data },
      status: "finalizing",
    })
    .where(eq(briefs.id, sc.brief.id));

  return {
    tokensIn: res.tokensIn,
    tokensOut: res.tokensOut,
    preview: `Meta ready: "${String(data.meta_title).slice(0, 80)}"`,
  };
}

// Helpers: cleanup, links, validation, schema.

export function humanizeText(text: string): string {
  return (
    text
      // Remove accidental in-paragraph bold (headings untouched).
      .replace(/(?<!^#{1,6}\s*)\*\*([^\n]+)\*\*/g, "$1")
      // Machine-like wording -> simple.
      .replace(/\butili[sz]e\b/gi, "use")
      .replace(/\bcommence\b/gi, "start")
      .replace(/\bapproximately\b/gi, "about")
      .replace(/\bnumerous\b/gi, "many")
      .replace(/\bindividuals\b/gi, "people")
      .replace(/\bin order to\b/gi, "to")
      .replace(/\bdue to the fact that\b/gi, "because")
      .replace(/\ba number of\b/gi, "several")
      .replace(/\bIt is important to note that\b/gi, "")
      .replace(/\bIn today's fast-paced world\b/gi, "")
      .replace(/\bFurthermore,?\s/gi, "Also, ")
      .replace(/\bMoreover,?\s/gi, "In addition, ")
      .replace(/\bdelve into\b/gi, "explore")
      // Clean extra spaces inside lines (never touch newlines,
      // or the whole markdown collapses into one line).
      .replace(/[ \t]{2,}/g, " ")
      .replace(/[ \t]+$/gm, "")
      // 3+ blank lines -> 2 (markdown never needs more).
      .replace(/\n{3,}/g, "\n\n")
      .trim()
  );
}

// Builds the real FAQ section from answered questions.
export function buildFaqSection(faq: Array<{ question: string; answer: string }>): string {
  if (!faq?.length) return "";
  return `## Frequently asked questions\n\n${faq
    .map((f) => `### ${f.question}\n\n${f.answer}`)
    .join("\n\n")}`;
}

// Replaces the FAQ placeholder with the real answered section.
export function replaceFaqPlaceholder(article: string, faq: Array<{ question: string; answer: string }>): string {
  if (!faq?.length) return article;
  const faqSection = buildFaqSection(faq);
  const pattern = /## Frequently asked questions[\s\S]*$/i;
  if (pattern.test(article)) {
    return article.replace(pattern, faqSection);
  }
  return `${article}\n\n${faqSection}`;
}

export async function injectLinks(projectId: number, article: string, research: Record<string, unknown>) {
  // Internal links: use the project's link library when filled.
  const links = await db.query.linkLibrary.findMany({
    where: eq(linkLibrary.projectId, projectId),
    limit: 10,
  });

  const internal: Array<{ anchor: string; url: string; section: string }> = [];
  for (const link of links) {
    const options = (link.anchorOptions || []) as string[];
    const anchor = options[0] || link.pageTitle || link.h1;
    if (anchor && link.url) {
      // Only keep links whose anchor really appears in the article.
      if (article.toLowerCase().includes(String(anchor).toLowerCase().slice(0, 25))) {
        internal.push({ anchor: String(anchor).slice(0, 60), url: link.url, section: "body" });
      }
    }
  }

  // External links: real domains from research top_results.
  const topResults = (research.top_results as Array<{ title: string; url: string }>) || [];
  const external = topResults.slice(0, 3).map((r) => ({
    anchor: r.title || "reference",
    url: r.url,
    domain: (() => {
      try {
        return new URL(r.url).hostname.replace("www.", "");
      } catch {
        return "example.com";
      }
    })(),
    rel: "noopener",
    note: "competitor reference — replace with your own source before publishing",
  }));

  return { internal, external };
}

export function validateContent(
  text: string,
  meta: { meta_title?: string; meta_description?: string },
  primaryKeyword: string,
  targetWords: number
) {
  const words = countWords(text);
  const h1Count = (text.match(/^# /gm) || []).length;
  const h2Count = (text.match(/^## /gm) || []).length;
  const h3Count = (text.match(/^### /gm) || []).length;
  const keywordCount = primaryKeyword
    ? (text.toLowerCase().match(new RegExp(primaryKeyword.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g")) || []).length
    : 0;
  const density = words > 0 ? (keywordCount / words) * 100 : 0;

  const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 0);
  const avgSentence = sentences.length ? words / sentences.length : 0;
  const syllables = syllableCount(text);
  const flesch = words > 0 ? Math.max(0, 206.835 - 1.015 * avgSentence - 84.6 * (syllables / words)) : 0;

  const report = [
    { rule: "h1_count", status: h1Count === 1 ? "pass" : "fail", value: h1Count, hint: "Exactly one H1 required" },
    { rule: "h2_count", status: h2Count >= 4 ? "pass" : "warn", value: h2Count, hint: "At least 4 H2 sections" },
    { rule: "word_count", status: words >= targetWords * 0.7 ? "pass" : "warn", value: words, hint: `Target ${targetWords} words` },
    {
      rule: "keyword_density",
      status: density >= 0.4 && density <= 2.0 ? "pass" : "warn",
      value: Number(density.toFixed(2)),
      hint: "Keep between 0.4% and 2%",
    },
    { rule: "avg_sentence", status: avgSentence <= 25 ? "pass" : "warn", value: Number(avgSentence.toFixed(1)), hint: "Sentences under 25 words" },
    {
      rule: "meta_title_length",
      status: (meta.meta_title?.length || 0) >= 30 && (meta.meta_title?.length || 0) <= 65 ? "pass" : "warn",
      value: meta.meta_title?.length || 0,
      hint: "30-65 characters",
    },
    {
      rule: "meta_desc_length",
      status: (meta.meta_description?.length || 0) >= 120 && (meta.meta_description?.length || 0) <= 165 ? "pass" : "warn",
      value: meta.meta_description?.length || 0,
      hint: "120-165 characters",
    },
  ];

  const passes = report.filter((r) => r.status === "pass").length;
  const qualityScore = Math.round((passes / report.length) * 100);

  return {
    words,
    h1Count,
    h2Count,
    h3Count,
    keywordCount,
    keywordDensity: Number(density.toFixed(3)),
    readability: { flesch: Number(flesch.toFixed(1)) },
    avgSentence: Number(avgSentence.toFixed(1)),
    report,
    qualityScore,
  };
}

// JSON-LD schema, including FAQPage (Google rich results).
export function buildSchemaJson(
  contentType: string,
  meta: { meta_title?: string; meta_description?: string; slug?: string },
  faq: Array<{ question: string; answer: string }>,
  siteUrl?: string
) {
  const type =
    contentType === "blog_post" ? "BlogPosting" : contentType === "service_page" ? "Service" : "Article";

  const base: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": type,
    headline: meta.meta_title,
    description: meta.meta_description,
    ...(siteUrl && meta.slug ? { url: `${siteUrl}/${meta.slug}` } : {}),
  };

  if (!faq?.length) return base;

  return {
    "@context": "https://schema.org",
    "@graph": [
      base,
      {
        "@type": "FAQPage",
        mainEntity: faq.map((f) => ({
          "@type": "Question",
          name: f.question,
          acceptedAnswer: { "@type": "Answer", text: f.answer },
        })),
      },
    ],
  };
}

export function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

function syllableCount(text: string): number {
  return text.toLowerCase().split(/[^aeiouy]+/).filter(Boolean).length;
}